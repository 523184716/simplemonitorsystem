#!/usr/bin/env python
#coding:utf-8

def avg():
    pass

def hit():
    pass

def last():
    pass