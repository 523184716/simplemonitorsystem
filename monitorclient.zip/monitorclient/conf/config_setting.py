#!/usr/bin/env python
#coding:utf-8

from monitorsystem.monitorclient.localip_get import Get_local_ip
#host_ip = Get_local_ip()
host_ip = "10.36.3.74"
redis_ip = "10.36.3.74"