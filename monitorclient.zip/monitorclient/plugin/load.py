#!/usr/bin/env python
#coding:utf-8

def monitor():
    cpu = "test cpu"
    return cpu