#!/usr/bin/env python
#coding:utf-8

def monitor():
    network = "test network"
    return  network