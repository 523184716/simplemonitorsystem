#!/usr/bin/env python
#coding:utf-8

def monitor():
    memory = "test memory"
    return  memory